# 自动组装提示词

先填写实际图像中的主体、结构锁定项、光线方向和场景。不要将变量原样送进工具。以下为默认英文编辑提示词，按输入分流删改无关句子：

Use case: identity-preserve / premium commercial photo retouch.
Input 1 is the ONLY edit target. Other inputs are STYLE REFERENCES ONLY; do not borrow their identity, products, logos, text, poses or scenery.
Retouch this actual client photograph into a refined natural fashion/product campaign. Preserve the exact {subject identity and pose if present}, {product silhouette, construction, material, color, patterns, hardware, logos and readable text}, their scale, positions and physical contact. Preserve the original aspect ratio and framing.
Art direction: sophisticated natural photography, restrained palette, believable skin and tactile original materials, calm background, product-first visual hierarchy. {Select daylight appropriate to input: preserve existing warm directional sun with subtle fill / preserve overcast soft daylight / use broad directional studio light.} Gently soften harsh highlights and reveal shadow detail without flattening volume. Preserve the actual product color and material. For dark areas retain depth and readable detail; for light, colored, translucent or reflective areas retain their actual optical character. No invented grain pattern or material substitution. Skin retains pores, natural features and realistic color.
{Outdoor: retain the actual location type and recognizable main setting; clean small distracting clutter, simplify competing colors and excessive ground damage; subtle optical depth, no smeared blur. Moderately mute saturated blues only where present, with nuanced dusty blue sky if appropriate.}
{Studio: retain or refine the simple neutral backdrop, soft directional light and realistic contact shadows; no outdoor conversion.}
{Product only: retain exact product; retain original background type and transparency; refine lighting without replacing the setting; grounded natural shadow, no added people, hands, props or travel narrative. Respect transparency when requested.}
Make {the uploaded product} the visual hero through controlled luminance, separation and texture, not by redesigning it. Remove only clear transient dirt or photographic artifacts; preserve intentional texture, folds, surface finish and construction. Do not infer hidden details. Preserve existing typography verbatim; add no new text.
Finish with subtle filmic highlight rolloff, restrained color and believable photographic detail. Avoid HDR, excessive sharpening, orange skin, crushed blacks, artificial glow, heavy grain, beauty-filter faces, changing identity, changing product design or labels, and copying reference branding.

## 迁移原则

产品是通用品类变量，不预设具体商品。以输入照片中的外观为唯一依据：尽量保留轮廓、尺寸比例、结构、颜色、部件、图案与标识，只改善光影、反光与原有材质的表现。参考只提供精致自然的摄影感。若风格与外观一致性冲突，降低风格强度。未经要求不变换产品材料、重塑形态或补充不可见细节。

额外加入实际编辑提示词：
Product fidelity takes priority over stylistic transformation. The uploaded target is the sole authority for product appearance. Improve illumination, tonal separation and the visibility of its EXISTING material, with minimal change to the product itself. Do not reshape, stretch, redesign, recolor, change thickness or proportions, add/remove components, move contact points, invent detail, or import any reference product features. Retain placement, orientation, wearing/use relationships and visible branding. If a detail is unclear, keep it understated rather than reconstructing it. Use a gentler edit whenever fidelity is at risk.

## 输出检查

对比输入：产品轮廓与比例是否接近原图？部件数量、连接方式、佩戴位置和朝向是否一致？颜色、材质、图案、标识是否改变？小细节是否被凭空补画？人物身份、手部及接触关系是否自然？新增的光影是否物理合理？明显变形则针对性修正，不将外观有偏差的试修称为完全保真。
